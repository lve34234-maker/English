-- ═══════════════════════════════════════════════
-- WordVault Supabase Schema
-- Supabase > SQL Editor 에서 이 전체 내용을 실행하세요
-- ═══════════════════════════════════════════════

-- 1) 사용자 프로필 (auth.users 와 연결)
CREATE TABLE IF NOT EXISTS wv_profiles (
  id UUID PRIMARY KEY,
  name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'child' CHECK (role IN ('parent','child')),
  family_id UUID,        -- 부모 = 자신의 UUID, 자녀 = 부모 UUID
  emoji TEXT DEFAULT '🧒',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2) 단어 (부모만 추가, family_id 로 가족 공유)
CREATE TABLE IF NOT EXISTS wv_words (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  family_id UUID NOT NULL,
  english TEXT NOT NULL,
  korean TEXT NOT NULL,
  phonetic TEXT DEFAULT '',
  example TEXT DEFAULT '',
  difficulty TEXT DEFAULT 'medium' CHECK (difficulty IN ('easy','medium','hard')),
  created_by UUID,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3) 퀴즈 기록 (하루 5회 제한)
CREATE TABLE IF NOT EXISTS wv_quiz_logs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  word_id UUID,
  word_english TEXT,
  word_korean TEXT,
  is_correct BOOLEAN DEFAULT FALSE,
  points_earned INT DEFAULT 0,
  logged_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4) 플래시카드 기록 (하루 최대 15포인트)
CREATE TABLE IF NOT EXISTS wv_fc_logs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  word_id UUID,
  word_english TEXT,
  grade TEXT DEFAULT 'good',
  points_earned INT DEFAULT 0,
  logged_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5) 포인트 내역 (퀴즈 자동 + 부모 수동 적립 모두)
CREATE TABLE IF NOT EXISTS wv_point_logs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  points INT NOT NULL,
  reason TEXT DEFAULT '',
  source TEXT DEFAULT 'manual' CHECK (source IN ('quiz','flashcard','manual','reset')),
  added_by UUID,
  added_by_name TEXT DEFAULT '',
  logged_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS 비활성화 (개발 단계 — 나중에 설정 가능)
ALTER TABLE wv_profiles    DISABLE ROW LEVEL SECURITY;
ALTER TABLE wv_words       DISABLE ROW LEVEL SECURITY;
ALTER TABLE wv_quiz_logs   DISABLE ROW LEVEL SECURITY;
ALTER TABLE wv_fc_logs     DISABLE ROW LEVEL SECURITY;
ALTER TABLE wv_point_logs  DISABLE ROW LEVEL SECURITY;

-- 샘플 단어 추가용 함수 (선택사항)
-- INSERT INTO wv_words (family_id, english, korean, difficulty) VALUES
-- ('YOUR_PARENT_UUID', 'ephemeral', '일시적인', 'hard'),
-- ('YOUR_PARENT_UUID', 'resilient', '회복력 있는', 'medium');
